Thanks a lot for collaborating! This will help me for my research on creating better videogames.

The steps to follow are:

1. If you are on Windows, double-click the file "WINDOWS" (perhaps you see it as "Windows.bat")
   If you are on a Mac, double-click the file "MAC"
   If you are on Linux, double-click the file "LINUX"

A window may pop adivising caution or requesting permissions. Click "Yes" or "Run".

2. A Mario game will come up. Play! Use the arrows, and keys A and S. Don't worry about anything, just play to have fun.

3. When the level ends, be it with a "Game over" or a "Thanks for rescuing me, Mario!", close the game window.

4. Two new files will show up, "DetailedInfo.txt" (or just "DetailedInfo") and "player.txt" (or just "player")

5. Please please please send both of them to jorge@diz.es

6. Receive my eternal gratitude. You can delete everything now.

These files are really important for my thesis research, so believe me when I say I will be really grateful.

The game does absolutely nothing harmful to your computer. The code is there for everyone to check and verify.

For anything, contact me at that same email, jorge@diz.es



----- Frequently Asked Questions -----

Q: Some weird error came up! Aaah you fucked my computer!

A: Your computer is fine. It's my game what crashed. Your computer is untouched. It probably just means you don't have Java installed (something that many programs require). That's quite rare, but it can happen.

Before contacting me, open the folder "mario", then the folder "bin" and check if the two files are there. If they are not, write me an email telling me the error you get and I'll help you through it :)



Q: I am really bad at Mario, you shouldn't use me for this...

A: Don't say that! It's not about playing in any way, your way of playing is unique and that's what I'm studying! Get your grandma, and your son, and your pal and everybody to play. Everybody is great for my research and actually the more diverse the profiles the best!



Q: Do I need to complete the level? I keep dying...

A: No, no! Dying is fine too. Anything is fine. Just play, don't worry.



Q: How many times should I play? This is fun.

A: It is, isn't it? You can play as much as you want, but the files only keep information for the last time you played.



Q: I know my way with computers. I can send you files from every time I play.

A: Thanks a lot! But that's actually bad and may lead to bad results. I want a set of files per person. Of course, if then you get your spouse, your parents, or somebody else to play, by all means, send all of them to me! As long as each set of files are are from different people, it's good.